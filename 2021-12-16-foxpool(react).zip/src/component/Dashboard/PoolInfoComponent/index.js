import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import utils from '../../../shared/utils';
import apidoc from '../../../shared/apidoc';

function PoolInfoComponent( { props } ) {
    // console.log(props)
    if (props === null){
        return (<div></div>)
    }

    const [share, setShare] = useState(0);

    var coinsymbol = useLocation();
    coinsymbol = coinsymbol.pathname.split("/")[1]
    coinsymbol = coinsymbol.replace('/', '')

    var reward ='';
    if (props.json4.pool.coin.type === 'ETH')
    {
        reward = '2 ETH + Tx Fee'
    } else if (props.json4.pool.coin.type === 'ZEC'){
        reward = '2.5 ZEC + Tx Fee'
    }
    else if (props.json4.pool.coin.type === 'ZEN'){
        reward = '3.75 ZEN + Tx Fee'
    }

    var minerList=[];
    Object.keys(props.json6).map((element)=>{
        minerList.push(props.json6[element].miner)
    })
 
    var totalShare = 0
    useEffect(() => {
        const promises= minerList.map((element) =>{
            return fetch(apidoc.apiUrl + coinsymbol + '/miners/' + element )
                .then(data => data.json())
        })
        Promise.all(promises)
        .then(
            (result) =>{
                Object.keys(result).map((element)=>{
                    totalShare +=result[element].pendingShares
                })
                setShare(totalShare)
            }
        
    )}, [props])


    var sharePercent = 0;
    if (share !=0) {
        sharePercent = utils.formatter(props.json3.pendingShares/share*100 ,2)
    }
 
    return (
        <div className="gray-bg-1">
            <div className="row mlr-1">
                <div className="col-6"> Unpaid Balance </div>
                <div className="col-6 text-right"> <span className="text-bold-1">{utils.formatter(props.json3.pendingBalance,5)} {props.json4.pool.coin.type}</span> </div>
            </div>
            <hr className="hrm" />
            <div className="row mlr-1">
                <div className="col-6"> Accepted Shares </div>
                <div className="col-6 text-right"> <span className="text-bold-1">{sharePercent} %</span> </div>
            </div>
            <hr className="hrm" />
            <div className="row mlr-1">
                <div className="col-6"> Minimum Payout </div>
                <div className="col-6 text-right"> <span className="text-bold-1">{props.json4.pool.paymentProcessing.minimumPayment} {props.json4.pool.coin.type}</span> </div>
            </div>
            <hr className="hrm" />
            <div className="row mlr-1">
                <div className="col-6"> Block Reward </div>
                {props.json4.pool.coin.type === 'ETH'?
                    <div className="col-6 text-right"> <span className="text-bold-1">{reward}<span className="text-success"> + MEV</span></span> </div>:
                    <div className="col-6 text-right"> <span className="text-bold-1">{reward}</span> </div>
                }
            </div>
            <hr className="hrm" />
            <div className="row mlr-1">
                <div className="col-6"> Pool Fee </div>
                <div className="col-6 text-right"> <span className="text-bold-1">{props.json4.pool.poolFeePercent}%</span> </div>
            </div>
    </div>
    );
  }
  
  export default PoolInfoComponent;
  
