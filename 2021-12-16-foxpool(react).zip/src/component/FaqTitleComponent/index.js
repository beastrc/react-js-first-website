function FaqTitleComponent( {props} ) {
    return (
        <h2 className="text-center" style={{marginBottom: `30px`}} >{props}</h2>
    );
}
  
  export default FaqTitleComponent;
  