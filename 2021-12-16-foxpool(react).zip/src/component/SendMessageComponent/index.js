import React, { useEffect } from 'react';
import AOS from 'aos';

function SendMessage()  {

 
    // const [name, SetName] = useState()
    // const [email, SetEmail] = useState()
    // const [phone, SetPhone] = useState()
    // const [companyname, SetCompanyname] = useState('')
    // const [message, SetMessage] = useState()

    useEffect(()=>{
        AOS.init({
            duration: 2500,
        })
    }) 

    const handleSubmit = (event) => {
        event.preventDefault();
        
        window.Email.send({
            Host : constant.EmailHost ,
            Username : constant.EmailUserName,
            Password : constant.EmailPassword ,
            To : constant.EmailDestination ,
            // Sendername : ,
            From : email,
            Subject : "Need to help from " + name,
            Body : message
        })
      }


        return (
            <section className="get-in-touch-section " 
    // beast find reason start
            data-aos={"fade-up"} data-aos-easing={"ease-out-cubic"}
            // data-aos-duration="2000"
    // beast find reason end
            >
                <div className="container ">
                    <h2>Get in touch with us. <span>We are happy to help.</span></h2>
                    <form onSubmit={handleSubmit}>
                        <div className="row ">
                            <div className="col-md-6 ">
                                <div className="row ">
                                    <div className="col-md-6 ">
                                        <div className="form-group ">
                                            <label htmlFor="name ">Name <span>*</span></label>
                                            <input id="name" type="text" className="form-control " placeholder="Name" aria-label="Name" onChange={(e)=> SetName(e.target.value)} required />
                                        </div>
                                    </div>
                                    <div className="col-md-6 ">
                                        <div className="form-group ">
                                            <label htmlFor="email">Your Email <span>*</span></label>
                                            <input id="email" type="email" placeholder="Your email" className="form-control" aria-label="Your email" onChange={(e)=> SetEmail(e.target.value)} required />
                                        </div>
                                    </div>
                                </div>
                                <div className="row ">
                                    <div className="col-md-6 ">
                                        <div className="form-group ">
                                            <label htmlFor="phone ">Phone #</label>
                                            <input id="phone " placeholder="Phone # " type="tel " className="form-control" aria-label="Phone #" onChange={(e)=> SetPhone(e.target.value)} required/>
                                        </div>
                                    </div>
                                    <div className="col-md-6 ">
                                        <div className="form-group ">
                                            <label htmlFor="company ">Company Name</label>
                                            <input placeholder="Company Name" type="text " className="form-control" aria-label="Company Name" onChange={(e)=> SetCompanyname(e.target.value)} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6 ">
                                <div className="form-group ">
                                    <label htmlFor="messages ">Message <span>*</span></label>
                                    <textarea id="messages" className="form-control" placeholder="Write your message *" aria-label="Write your message *" onChange={(e)=> SetMessage(e.target.value)}required></textarea>
                                </div>
                            </div>
                        </div>
                        <div className="d-flex justify-content-center ">
                            <button type="submit" className="btn-submit btn btn-primary ">Send Message</button>
                        </div>
                    </form>
                </div>
            </section>
        );
    
    }

  
  export default SendMessage;
  