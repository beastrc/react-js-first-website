import React from "react";
import { useEffect, useState } from "react";
import SpinnerComponent from '../../component/SpinnerComponent';

import FirstHeader from "../../component/FirstHeader";
import FirstBanner from "../../component/FirstBanner";
import PoolCoin from "../../component/PoolcoinComponent";
import ConnectFoxPool from "../../component/ConnectFoxpoolComponent";
import SendMessage from "../../component/SendMessageComponent";
import Footer from "../../component/FooterComponent";

const FirstScreen = () => {
  // function FirstScreen() {

  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const loadData = async() =>{
        // Wait for two second
        await new Promise((r) => setTimeout(r, 2000));
  
        // Toggle loading state
        setLoading((loading) => !loading);      
    };
    loadData();
  }, [])

  // return (
  if(loading) {
    return <SpinnerComponent />
  }
  else {
    return (
      <div>
        <FirstHeader />
        <FirstBanner />
        <PoolCoin />
        <ConnectFoxPool />
        <SendMessage />
        <Footer />
      </div>
    )
  }
  // );
}

export default FirstScreen;
