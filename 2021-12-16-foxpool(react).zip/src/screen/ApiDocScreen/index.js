import { Link } from 'react-router-dom';
import FirstHeader from "../../component/FirstHeader";
import BannerComponent from "../../component/BannerComponent";
import Footer from "../../component/FooterComponent";
import blog_icon from '../../assets/images/blog-icon.png';

function ApiDocScreen() {
  return (
    <div>
      {/* <SpinnerComponent /> */}
        <FirstHeader />
        <BannerComponent image={ blog_icon } label="Foxpool Blog" />
        <section className="innerpage-content">
        <div>
          {/*
   API Documentation HTML Template  - 1.0.1
   Copyright © 2016 Florian Nicolas
   Licensed under the MIT license.
   https://github.com/ticlekiwi/API-Documentation-HTML-Template
   !*/}
          <meta charSet="utf-8" />
          <title>API - Documentation</title>
          <meta name="description" content />
          <meta name="author" content="ticlekiwi" />
          <meta httpEquiv="cleartype" content="on" />
          <meta httpEquiv="X-UA-Compatible" content="IE=edge,chrome=1" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <link rel="stylesheet" href="css/hightlightjs-dark.css" />
          <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,500|Source+Code+Pro:300" rel="stylesheet" />
          <link rel="stylesheet" href="css/style.css" media="all" />
          <div className="left-menu">
            <div className="content-logo">
              <img alt="platform by Emily van den Heever from the Noun Project" title="platform by Emily van den Heever from the Noun Project" src="images/logo.png" height={32} />
              <span>API Documentation</span>
            </div>
            <div className="content-menu">
              <ul>
                <li className="scroll-to-link active" data-target="get-started">
                  <a>GET STARTED</a>
                </li>
                <li className="scroll-to-link" data-target="get-characters">
                  <a>Get Pool Information</a>
                </li>
              </ul>
            </div>
          </div>
          <div className="content-page">
            <div className="content-code" />
            <div className="content">
              <div className="overflow-hidden content-section" id="content-get-started">
                <h1 id="get-started">Get started</h1>
                <pre>{"    "}API Endpoint{"\n"}{"\n"}{"    "}http://mining4pros.com/api/pools{"\n"}{"                "}</pre>
                <p>
                  The Mining4Pros API provides access to our entire Pool data.
                </p>
                <p>
                  To use this API, just target the curl request based on your desired information.
                </p>
              </div>
              <div className="overflow-hidden content-section" id="content-get-characters">
                <h2 id="get-characters">get pool information</h2>
                <pre><code className="bash">{"\n"}# Here is a curl example{"\n"}curl https://mining4pros.com/api/pools/zec {"\n"}{"\n"}{"                "}</code></pre>
                <p>
                  To get Pool information you need to make a POST call to the following url :<br />
                  <code className="higlighted">https://mining4pros.com/api/pools<racter get code>
                    </racter></code></p><code className="higlighted">
                  <br />
                  <pre><code className="json">{"\n"}Result example :{"\n"}{"{"}{"\n"}{"    "}"pool": {"{"}{"\n"}{"      "}"id": "zec",{"\n"}{"      "}"coin": {"{"}{"\n"}{"        "}"type": "ZEC",{"\n"}{"        "}"name": "ZCash",{"\n"}{"        "}"family": "equihash",{"\n"}{"        "}"algorithm": "Equihash"{"\n"}{"      "}{"}"},{"\n"}{"      "}"ports": {"{"}{"\n"}{"        "}"3082": {"{"}{"\n"}{"          "}"listenAddress": "0.0.0.0",{"\n"}{"          "}"name": null,{"\n"}{"          "}"difficulty": 600.0,{"\n"}{"          "}"tcpProxyProtocol": null,{"\n"}{"          "}"varDiff": {"{"}{"\n"}{"            "}"minDiff": 600.0,{"\n"}{"            "}"maxDiff": null,{"\n"}{"            "}"maxDelta": 150.0,{"\n"}{"            "}"targetTime": 15.0,{"\n"}{"            "}"retargetTime": 90.0,{"\n"}{"            "}"variancePercent": 30.0{"\n"}{"          "}{"}"},{"\n"}{"          "}"tls": false,{"\n"}{"          "}"tlsPfxFile": null{"\n"}{"        "}{"}"}{"\n"}{"      "}{"}"},{"\n"}{"      "}"paymentProcessing": {"{"}{"\n"}{"        "}"enabled": true,{"\n"}{"        "}"minimumPayment": 0.01,{"\n"}{"        "}"payoutScheme": "PPLNS",{"\n"}{"        "}"payoutSchemeConfig": {"{"}{"\n"}{"          "}"factor": 2.0{"\n"}{"        "}{"}"}{"\n"}{"      "}{"}"},{"\n"}{"      "}"shareBasedBanning": null,{"\n"}{"      "}"clientConnectionTimeout": 600,{"\n"}{"      "}"jobRebroadcastTimeout": 10,{"\n"}{"      "}"blockRefreshInterval": 500,{"\n"}{"      "}"poolFeePercent": 0.0,{"\n"}{"      "}"address": "t1QGNftnPTNC6jaYEMqhPjnK7TjVB4GV1vd",{"\n"}{"      "}"addressInfoLink": "https://explorer.zcha.in/accounts/t1QGNftnPTNC6jaYEMqhPjnK7TjVB4GV1vd",{"\n"}{"      "}"poolStats": {"{"}{"\n"}{"        "}"lastPoolBlockTime": null,{"\n"}{"        "}"connectedMiners": 1,{"\n"}{"        "}"connectedWorkers": 0,{"\n"}{"        "}"poolHashrate": 2021372.25,{"\n"}{"        "}"sharesPerSecond": 0{"\n"}{"      "}{"}"},{"\n"}{"      "}"networkStats": {"{"}{"\n"}{"        "}"networkType": "Main",{"\n"}{"        "}"networkHashrate": 4791131725.0,{"\n"}{"        "}"networkDifficulty": 47251192.667483181,{"\n"}{"        "}"nextNetworkTarget": "0000000002d72c00000000000000000000000000000000000000000000000000",{"\n"}{"        "}"nextNetworkBits": "1c02d72c",{"\n"}{"        "}"lastNetworkBlockTime": "2021-08-31T11:03:24.9662536Z",{"\n"}{"        "}"blockHeight": 1373975,{"\n"}{"        "}"connectedPeers": 8,{"\n"}{"        "}"rewardType": "POW"{"\n"}{"      "}{"}"},{"\n"}{"      "}"topMiners": [{"\n"}{"        "}{"{"}{"\n"}{"          "}"miner": "t1PsU1HCVHS4n9uni9Rhz4q6Vwvyo3RzNvC",{"\n"}{"          "}"hashrate": 639950.0,{"\n"}{"          "}"sharesPerSecond": 0.072{"\n"}{"        "}{"}"}{"\n"}{"      "}],{"\n"}{"      "}"totalPaid": 115.023163894630{"\n"}{"    "}{"}"}{"\n"}{"  "}{"}"}{"                                                     "}{"\n"}{"                "}</code></pre>
                  <h4>QUERY PARAMETERS</h4>
                  <table>
                    <thead>
                      <tr>
                        <th>Field</th>
                        <th>Type</th>
                        <th>Description</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>coin_ID</td>
                        <td>String</td>
                        <td>Any coin_ID that is listed on our pool</td>
                      </tr>
                      <tr>
                        <td>/coin_ID/blocks</td>
                        <td>String</td>
                        <td>Show latest blocks found by the Pool</td>
                      </tr>
                      <tr>
                        <td>coin_ID/payments</td>
                        <td>String</td>
                        <td>
                          Show latest Payments made by the pool
                        </td>
                      </tr>
                      <tr>
                        <td>coin_ID/miners</td>
                        <td>String</td>
                        <td>
                          Show all connected miners
                        </td>
                      </tr>
                      <tr>
                        <td>/coin_ID/performance</td>
                        <td>String</td>
                        <td>
                          Show the hashrate of the Pool
                        </td>
                      </tr>
                      <tr>
                        <td>/coin_ID/miners/"Your Personal Wallet Adress"</td>
                        <td>Address</td>
                        <td>Get personal dashboard information</td>
                      </tr>
                    </tbody>
                  </table>
                </code></div><code className="higlighted">
              </code></div><code className="higlighted">
              <div className="content-code" />
            </code></div><code className="higlighted">
          </code></div>

        </section>
        <Footer />
    </div>
  );
}

export default ApiDocScreen;