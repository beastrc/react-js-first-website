module.exports = {
    weburl : '',
    apiUrl : 'https://mining4pros.com/api/pools/',
    stratum: window.location.hostname,
    PhoenixminerAddress: '/app/Setup.zip',
    // blockEtherUrl : 'https://etherscan.io/block/',
    // paymentUrl : 'https://etherscan.io/tx/',
}

